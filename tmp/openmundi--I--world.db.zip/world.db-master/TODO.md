# ToDos

- check missing flag for sx for world.db.flags


# Renames

- [ ]  change 1-codes to 1--country-codes ??
