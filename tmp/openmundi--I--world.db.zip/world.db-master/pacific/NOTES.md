# Notes on Pacific (Oceania w/ Australia)


Regions
=======

- Melanesia  - <http://en.wikipedia.org/wiki/Melanesia>
- Micronesia - <http://en.wikipedia.org/wiki/Micronesia>
- Polynesia  - <http://en.wikipedia.org/wiki/Polynesia>

