# Notes on Netherlands (nl)



### Wikipedia

- [NUTS_of_the_Netherlands](http://en.wikipedia.org/wiki/NUTS_of_the_Netherlands) - Regions
- [ISO_3166-2:NL](http://en.wikipedia.org/wiki/ISO_3166-2:NL)

## Sources

- [Statoids Netherlands](http://www.statoids.com/unl.html)


## Regions

- Use ISO 3166-2 for two-letter codes

## Keys / Codes
