

### Standings


```
                                        - Total -                  - Home -          - Away -     
                                 Pld   W  D  L   F:A   +/-  Pts   W  D  L   F:A     W  D  L   F:A
 1. Chelsea                        0   0  0  0   0:0          0   0  0  0   0:0     0  0  0   0:0  
 2. Arsenal                        0   0  0  0   0:0          0   0  0  0   0:0     0  0  0   0:0  
 3. Tottenham Hotspur              0   0  0  0   0:0          0   0  0  0   0:0     0  0  0   0:0  
 4. West Ham United                0   0  0  0   0:0          0   0  0  0   0:0     0  0  0   0:0  
 5. Crystal Palace                 0   0  0  0   0:0          0   0  0  0   0:0     0  0  0   0:0  
 6. Manchester United              0   0  0  0   0:0          0   0  0  0   0:0     0  0  0   0:0  
 7. Manchester City                0   0  0  0   0:0          0   0  0  0   0:0     0  0  0   0:0  
 8. Everton                        0   0  0  0   0:0          0   0  0  0   0:0     0  0  0   0:0  
 9. Liverpool                      0   0  0  0   0:0          0   0  0  0   0:0     0  0  0   0:0  
10. West Bromwich Albion           0   0  0  0   0:0          0   0  0  0   0:0     0  0  0   0:0  
11. Newcastle United               0   0  0  0   0:0          0   0  0  0   0:0     0  0  0   0:0  
12. Stoke City                     0   0  0  0   0:0          0   0  0  0   0:0     0  0  0   0:0  
13. Southampton                    0   0  0  0   0:0          0   0  0  0   0:0     0  0  0   0:0  
14. Leicester City                 0   0  0  0   0:0          0   0  0  0   0:0     0  0  0   0:0  
15. Bournemouth                    0   0  0  0   0:0          0   0  0  0   0:0     0  0  0   0:0  
16. Watford                        0   0  0  0   0:0          0   0  0  0   0:0     0  0  0   0:0  
17. Brighton & Hove Albion         0   0  0  0   0:0          0   0  0  0   0:0     0  0  0   0:0  
18. Burnley                        0   0  0  0   0:0          0   0  0  0   0:0     0  0  0   0:0  
19. Huddersfield Town              0   0  0  0   0:0          0   0  0  0   0:0     0  0  0   0:0  
20. Swansea                        0   0  0  0   0:0          0   0  0  0   0:0     0  0  0   0:0  
```




---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

### Results Tables

```
Home \ Away           CHE ARS TOT WHU CRY MUN MCI EVE LIV WBA NEW STK SOU LEI BOU WAT     BUR     SWA
Chelsea (CHE)          *
Arsenal (ARS)              *
Tottenham Hotsp (TOT)          *
West Ham United (WHU)              *
Crystal Palace (CRY)                   *
Manchester Unit (MUN)                      *
Manchester City (MCI)                          *
Everton (EVE)                                      *
Liverpool (LIV)                                        *
West Bromwich A (WBA)                                      *
Newcastle Unite (NEW)                                          *
Stoke City (STK)                                                   *
Southampton (SOU)                                                      *
Leicester City (LEI)                                                       *
Bournemouth (BOU)                                                              *
Watford (WAT)                                                                      *
Brighton & Hove ()                                                                     *
Burnley (BUR)                                                                              *
Huddersfield To ()                                                                             *
Swansea (SWA)                                                                                      *

```


